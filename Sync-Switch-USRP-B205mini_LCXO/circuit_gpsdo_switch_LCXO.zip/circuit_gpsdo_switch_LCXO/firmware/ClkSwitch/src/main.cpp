/**
 * @brief Firmware for the microcontroller on the GPSDO carrier board to switch output clock between 1 PPS and 10 MHz.
 * The microcontroller expects UART commands to switch.
 * To enable the UART port on a Raspberry Pi:
 *   sudo raspi-config
 *     Select “Interface Options” -> “Serial Port” -> login shell accessible: <No> -> enable serial hardware port: <Yes>
 *     Select "Finish" and reboot
 *   Alternatively: 
 *     sudo nano /boot/firmware/config.txt -> below [all], add line "dtparam=uart0=on"
 *     sudo nano /boot/firmware/cmdline.txt -> remove "console=serial0,115200"
 * Use /dev/ttyAMA0 for communication
*/
#include <Arduino.h>

#define PIN_1PPS PA0
#define PIN_10MHZ PA1

const char header[] = "CLK:";

void setup() {
	// init GPIO
	pinMode(PIN_1PPS, OUTPUT);
	pinMode(PIN_10MHZ, OUTPUT);

	// init UART
	Serial.begin(115200);
}

void loop() {
	static int iByte = 0;
	if (Serial.available() > 0) {
		// read the incoming bytes
		int inByte = Serial.read();
		if (iByte < 4) {
			// check for correct header
			if (inByte == header[iByte]) {
				iByte++;
			} else {
				iByte = 0;
			}
		} else {
			// check value
			if (inByte == 0x4D) {
				// "M[Hz]"
				digitalWrite(PIN_10MHZ, HIGH);
				Serial.println(1); // confirm
				delay(10);
				digitalWrite(PIN_10MHZ, LOW);
			} else if (inByte == 0x50) {
				// "P[PS]"
				digitalWrite(PIN_1PPS, HIGH);
				Serial.println(1); // confirm
				delay(10);
				digitalWrite(PIN_1PPS, LOW);
			}
			iByte = 0;
		}
	}
}