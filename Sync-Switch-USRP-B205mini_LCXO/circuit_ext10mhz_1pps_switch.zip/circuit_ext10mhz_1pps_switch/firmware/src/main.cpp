#include <Arduino.h>

#define SW_1PPS PA1
#define SW_10MHZ PA0
#define LED_1PPS PA3
#define LED_10MHZ PA2

const char header[] = "CLK:";

void setup() {
	// init GPIO
	pinMode(SW_1PPS, OUTPUT);
	pinMode(SW_10MHZ, OUTPUT);
	pinMode(LED_1PPS, OUTPUT);
	pinMode(LED_10MHZ, OUTPUT);

	// switch to 1 PPS
	digitalWrite(SW_1PPS, HIGH);
	digitalWrite(LED_1PPS, HIGH);
	delay(10);
	digitalWrite(SW_1PPS, LOW);

	// init UART
	Serial.begin(115200);
}

void loop() {
	static int iByte = 0;
	if (Serial.available() > 0) {
		// read the incoming bytes
		int inByte = Serial.read();
		if (iByte < 4) {
			// check for correct header
			if (inByte == header[iByte]) {
				iByte++;
			} else {
				iByte = 0;
			}
		} else {
			// check value
			if (inByte == 0x4D) {
				// "M[Hz]"
				digitalWrite(SW_10MHZ, HIGH);
				digitalWrite(LED_10MHZ, HIGH);
				digitalWrite(LED_1PPS, LOW);
				Serial.println(1); // confirm
				delay(10);
				digitalWrite(SW_10MHZ, LOW);
			} else if (inByte == 0x50) {
				// "P[PS]"
				digitalWrite(SW_1PPS, HIGH);
				digitalWrite(LED_1PPS, HIGH);
				digitalWrite(LED_10MHZ, LOW);
				Serial.println(1); // confirm
				delay(10);
				digitalWrite(SW_1PPS, LOW);
			}
			iByte = 0;
		}
	}
}