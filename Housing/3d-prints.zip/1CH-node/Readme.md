# Instructions for 3D printed UAV case

## 3D print housing parts
* construction done using SolveSpace 
* use e.g. PrusaSlicer to prepare .STL files for printing

* estimated printing times:
    * **case** housing.stl ~ 12.5 hours

    <img src="./photos/housing.png" alt="drawing" width="100"/>

    * **cover** housing.stl ~ 1.25 hours

    <img src="./photos/cover.png" alt="drawing" width="100"/>

    * **inner layer top** inner_layer1.stl ~ 2 hours

    <img src="./photos/inner_layer1.png" alt="drawing" width="100"/>

    * **inner layer bottom** inner_layer2.stl ~ 2 hours

    <img src="./photos/inner_layer2.png" alt="drawing" width="100"/>

    * **LNA mounting** lna_clamp.stl, lna_spacer.stl ~ 10 min

    * 2x **GNSS antenna mount** antenna_gnss_mount.stl ~ 15 min

    * **RF antenna mount** antenna_omni_mount.stl ~ 35 min

    <img src="./photos/antenna_omni_mount.png" alt="drawing" width="60"/>



# Mount RF antenna to case
* mount antenna at antenna_omni_mount.stl using
    * 2 M3x20 head screws Nylon
    * 4 M3x20+6 distance piece Nylon 
    * 2 M3 nuts Nylon
* mount antenna at housing.stl using
    * 4 M3 locking nuts
    * 4 M3x10 head screws

<img src="./photos/ant_omni1.jpg" alt="drawing" width="150"/>
<img src="./photos/ant_omni2.jpg" alt="drawing" width="150"/>
<img src="./photos/ant_omni3.jpg" alt="drawing" width="150"/>

## Mount LTE stick to drone
* cable tie

## Mount GNSS antennas to drone
* provided by CiS: mounting and 8mm carbon tube
* antenna_gnss_mount.stl

<img src="./photos/ORKA_gnss1.jpg" alt="drawing" width="100"/>
<img src="./photos/ORKA_gnss2.jpg" alt="drawing" width="150"/>
<img src="./photos/ORKA_gnss3.jpg" alt="drawing" width="100"/>


<img src="./photos/ant_gnss1.jpg" alt="drawing" width="200"/>
<img src="./photos/ant_gnss2.jpg" alt="drawing" width="200"/>
<img src="./photos/ant_gnss3.jpg" alt="drawing" width="200"/>
<img src="./photos/ant_gnss4.jpg" alt="drawing" width="200"/>

## Mount housing to drone
* mount housing to drone using M3 screws + vibration dampers (provided by CiS)

<img src="./photos/case_ORKA1.png" alt="drawing" width="200"/>
<img src="./photos/case_ORKA2.png" alt="drawing" width="200"/>

## Mount measurement devices at inner layers

#### Place powerbank at top inner layer

#### Mount USRP B205mini at bottom inner layer
* 4 M3x30 head screws
* 4 5mm distance pieces

<img src="./photos/usrp01.jpg" alt="drawing" width="200"/>
<img src="./photos/usrp02.jpg" alt="drawing" width="200"/>
<img src="./photos/usrp03.jpg" alt="drawing" width="200"/>

#### Mount Raspberry Pi 5, Pineberry Pi and GPSDO at bottom inner layer
* drill holes at Raspi and Pineberry Pi to M3
* 4 8mm distance pieces
* 4 M3 8mm distance pieces
* 4 M3x16 head screws
* mount Pineberry Pi (insert SD card at Raspberry Pi)

<img src="./photos/raspi01.jpg" alt="drawing" width="200"/>
<img src="./photos/raspi02.jpg" alt="drawing" width="200"/>

* 2 M3x30 head screws
* 2 17mm + 5mm distance pieces
* 2 M3x10 head screws
* 2 5mm distance pieces
* mount Raspberry Pi and GPSDO circuit board

<img src="./photos/raspi03.jpg" alt="drawing" width="200"/>

#### Mount simplertk2b at bottom inner layer
* 3 M3x10 head screws
* 3 M3 locking nuts

<img src="./photos/rtk01.jpg" alt="drawing" width="200"/>
<img src="./photos/rtk02.jpg" alt="drawing" width="200"/>

#### Mount amplifier at bottom inner layer
* 3d printed distance pieces lna_clamp.stl and lna_spacer.stl
* 2 M2.5x20 head screws
* 2 M2.5 nuts

<img src="./photos/lna01.HEIF" alt="drawing" width="200"/>
<img src="./photos/lna02.jpg" alt="drawing" width="200"/>
<img src="./photos/lna03.jpg" alt="drawing" width="200"/>

#### Mount cables
* connect Raspberry Pi to LTE stick (USB A extension using center hole in housing)
* connect Raspberry Pi to simplertk2b (USB micro - USB 2.0 A)
* connect Raspberry Pi to USRP B205mini (angled USB micro B - USB 3.0 A)

<img src="./photos/cable02.jpg" alt="drawing" width="200"/>
<img src="./photos/cable01.jpg" alt="drawing" width="200"/>
<img src="./photos/cable03.jpg" alt="drawing" width="200"/>
<img src="./photos/cable04.jpg" alt="drawing" width="200"/>
<img src="./photos/cable05.jpg" alt="drawing" width="200"/>

* connect USRP B205mini to filters, LNA, HF antenna (SMA using lower hole in housing)
* connect GPSDO to GNSS antenna (SMA using left upper hole in housing)
* connect simplertk2b to GNSS antenna (SMA using right upper hole in housing)
* connect simplertk2b to GNSS antenna (SMA using right upper hole in housing)

* connect LNA with powerbank (USB A) 
* connect Raspberry Pi  with powerbank (USB C - USB A)

<img src="./photos/assembly01.jpg" alt="drawing" width="200"/>

## Close case
* using cover and 1 M3x11 self-tapping screw
* cable tie e.g. for HF sma cable to antenna

<img src="./photos/assembly02.jpg" alt="drawing" width="200"/>